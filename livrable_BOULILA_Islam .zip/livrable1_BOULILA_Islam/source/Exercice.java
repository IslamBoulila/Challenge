import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Exercice {

	public static void main(String[] args) {
		
		ArrayList<Double> xCoor =new ArrayList<>();//an array  of x coordinates of the houses
		ArrayList<Double> yCoor =new ArrayList<>();//an array  of y coordinates of the houses
		
		int index=0;//index to  browse the arrays of coordinates 
		double distance=0; //represents the distance  from the postman to a house
		double outputDistance;// distance of the closest house
		int output=0;  //index of the closest house to  the post man
		
		
		
		String filePath=args[0];//the file path
		Scanner sc = null;
		
		/*read the x and y coordinates from the input file
		 *  and save it in the arrayLists*/
		try {
				sc = new Scanner(new File(filePath));
			
				while(sc.hasNext()) {
				String []coor=sc.nextLine().split(",");
				xCoor.add(Double.parseDouble(coor[0]));
				yCoor.add(Double.parseDouble(coor[1]));
				
				}
			
			
			/*calculate the distance of the house in the first line */
			 outputDistance=Math.sqrt(Math.pow(xCoor.get(0),2)+Math.pow(yCoor.get(0),2));
				
			for( index=0;index <xCoor.size();index++) {
				distance =Math.sqrt(Math.pow(xCoor.get(index),2)+Math.pow(yCoor.get(index),2));
				
				/*compare the distance of the closest house already calculated
				 *  to the current house*/
				if(distance < outputDistance) {
					outputDistance=distance;
					output=index;
				}
				//print the output 
			}System.out.println(output);
			
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		

	}

}
