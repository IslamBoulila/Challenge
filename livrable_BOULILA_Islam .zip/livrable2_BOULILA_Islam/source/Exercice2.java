import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Exercice2 {

	public static void main(String[] args) {
		String filePath=args[0];
		try {
			Scanner input=new Scanner(new File(filePath));
			int lineNb=0;//line number
			String line="";
			
			while(input.hasNext()) {
				 line=input.nextLine();//read the line from the input file
				char  []charArray= line.toCharArray();
				
				/*an arrayList that will save all opening brackets in the same order
				 *  that they are in the input line*/
				ArrayList<Character> openBracket= new ArrayList<>(); 
				lineNb++;
				for(char c:charArray) {
					
					if(c=='{' | c=='(' |c=='[') {
						openBracket.add(c);			
						}
					else if (c=='}')
					{
						if( openBracket.get(openBracket.size()-1)=='{') {
							openBracket.remove(openBracket.size()-1);
						}
					}
					
					else if (c==')')
					{ /*if the last opening bracket match the actual closing bracket
					 we remove tit from the arrayList*/
						if( openBracket.get(openBracket.size()-1)=='(') {
							openBracket.remove(openBracket.size()-1);
						}
					}
					
					else if (c==']')
					{
						if(openBracket.get(openBracket.size()-1)=='[') {
							openBracket.remove(openBracket.size()-1);
						}
					}
					
					
					/*if the number of brackets in the arrayList is zero it means that
					 * there is no open brackets without o closing one in the line  */
				} if(openBracket.size()==0)
					System.out.println("ligne "+lineNb+":" +true);
				else System.out.println("ligne "+lineNb+":"+false);
				
				
			}
			
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
	
		
	}

}
