import java.util.ArrayList;
import java.util.Scanner;

public class Exercice3 {

	public static void main(String[] args) {
		
		
		String []input=args[0].split(",");
		int []tab=new int[input.length]; //an array that will contains the  horsepowers
		int i=0,j=0;
		int index;; //index of the matching horse
		
		int diff=0;  //difference between two numbers; two horsepowers
		
		/*array that will contain the indexes
		 that are already founded*/
		ArrayList<Integer> excluded=new ArrayList<>();
		
		 for(i=0;i<input.length;i++)
			 tab[i]=Integer.parseInt(input[i]);
		 
		for ( i=0;i<tab.length ;i++ ) {
			
			/*if i  is different of excluded index of horses that are already matched*/
			if(!(excluded.contains(i))) {
				index=-1;
				diff=1000;//initialize diff to a random number
				for(j=i+1;j<tab.length;j++) {
			
					if(diff> Math.abs(tab[i]-tab[j]) && !(excluded.contains(j))) {
						diff =Math.abs(tab[i]-tab[j]);
						index=j;
					}
				}
				if(index!=-1) { //found a matching horse
					System.out.println(i+" et "+index);
					//add the index of the matched horse
					excluded.add(index);
				
				}
				else { System.out.println(i);}
			}
	
		}
	}

}
